/* ============================================
   Admin Panel Routes
   ============================================ */

const express = require('express');
const db = require('../db');
const { issueAdminToken, requireAdmin } = require('../middleware/auth');

const router = express.Router();

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';

/**
 * POST /api/admin/login
 */
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password required' });
  }

  const userMatch = username === ADMIN_USERNAME;
  const passMatch = password === ADMIN_PASSWORD;

  if (!userMatch || !passMatch) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = issueAdminToken(username);
  res.json({ success: true, token, username });
});

/**
 * GET /api/admin/users
 */
router.get('/users', requireAdmin, (req, res) => {
  db.getAllUsersEnriched((err, rows) => {
    if (err) {
      console.error('DB error:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ success: true, count: rows.length, users: rows });
  });
});

/**
 * GET /api/admin/users/:id
 */
router.get('/users/:id', requireAdmin, (req, res) => {
  const userId = parseInt(req.params.id);
  db.findUserById(userId, (err, user) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!user) return res.status(404).json({ error: 'User not found' });
    db.getUserLoginHistory(userId, (err, history) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json({ user, history });
    });
  });
});

/**
 * GET /api/admin/stats
 */
router.get('/stats', requireAdmin, (req, res) => {
  db.getStats((err, stats) => {
    if (err) {
      console.error('Stats error:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ success: true, stats });
  });
});

/**
 * DELETE /api/admin/users/:id
 */
router.delete('/users/:id', requireAdmin, (req, res) => {
  const userId = parseInt(req.params.id);
  db.setUserActive(userId, false, (err, user) => {
    if (err) {
      if (err.message === 'User not found') return res.status(404).json({ error: 'User not found' });
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ success: true, message: 'User deactivated' });
  });
});

/**
 * POST /api/admin/users/:id/activate
 */
router.post('/users/:id/activate', requireAdmin, (req, res) => {
  const userId = parseInt(req.params.id);
  db.setUserActive(userId, true, (err, user) => {
    if (err) {
      if (err.message === 'User not found') return res.status(404).json({ error: 'User not found' });
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ success: true, message: 'User activated' });
  });
});

module.exports = router;
