/* ============================================
   Google OAuth Authentication Routes
   ============================================ */

const express = require('express');
const { OAuth2Client } = require('google-auth-library');
const db = require('../db');
const { issueUserToken } = require('../middleware/auth');

const router = express.Router();

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const client = new OAuth2Client(GOOGLE_CLIENT_ID);

const rateLimit = require('express-rate-limit');
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { error: 'Too many login attempts, please try again later' }
});

router.use(authLimiter);

/**
 * POST /api/auth/google
 * Body: { credential: "<google_jwt>" }
 */
router.post('/google', async (req, res) => {
  const { credential } = req.body;
  if (!credential) {
    return res.status(400).json({ error: 'Missing credential' });
  }

  if (!GOOGLE_CLIENT_ID || GOOGLE_CLIENT_ID === 'your-client-id-here.apps.googleusercontent.com') {
    return res.status(500).json({
      error: 'Server is not configured. Set GOOGLE_CLIENT_ID in environment variables. See SETUP.md'
    });
  }

  try {
    const ticket = await client.verifyIdToken({
      idToken: credential,
      audience: GOOGLE_CLIENT_ID
    });
    const payload = ticket.getPayload();

    const googleId = payload.sub;
    const email = payload.email;
    const name = payload.name || email.split('@')[0];
    const picture = payload.picture || null;
    const emailVerified = payload.email_verified || false;

    if (!emailVerified) {
      return res.status(400).json({ error: 'Email not verified by Google' });
    }

    const ip = req.ip || req.headers['x-forwarded-for'] || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';

    // Check if user exists
    db.findUserByGoogleId(googleId, (err, existingUser) => {
      if (err) {
        console.error('DB error:', err);
        return res.status(500).json({ error: 'Database error' });
      }

      const handleUserFound = (user) => {
        // Log the login
        db.logLogin(user.id, ip, userAgent, () => {});
        const token = issueUserToken(user);
        res.json({
          success: true,
          isNewUser: false,
          token,
          user: {
            id: user.id,
            google_id: user.google_id,
            email: user.email,
            name: user.name,
            picture: user.picture,
            joined_at: user.joined_at,
            login_count: user.login_count
          }
        });
      };

      if (existingUser) {
        // Update existing user
        db.updateUserLogin(googleId, name, picture, (err, updatedUser) => {
          if (err) {
            console.error('Update error:', err);
            return res.status(500).json({ error: 'Update failed' });
          }
          handleUserFound(updatedUser);
        });
      } else {
        // Create new user
        db.createUser({ google_id: googleId, email, name, picture }, (err, newUser) => {
          if (err) {
            console.error('Create error:', err);
            return res.status(500).json({ error: 'Could not create user' });
          }
          handleUserFound(newUser);
        });
      }
    });
  } catch (err) {
    console.error('Google verify error:', err);
    return res.status(401).json({ error: 'Invalid Google credential' });
  }
});

/**
 * GET /api/auth/me
 * Returns current user info
 */
router.get('/me', require('../middleware/auth').requireUser, (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
