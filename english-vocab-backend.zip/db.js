/* ============================================
   Simple JSON File Database
   No native dependencies — works everywhere
   ============================================ */

const fs = require('fs');
const path = require('path');

const DB_PATH = process.env.DB_PATH || './data/english-vocab-db.json';

// Ensure data directory exists
const dbDir = path.dirname(DB_PATH);
if (!fs.existsSync(dbDir)) {
  try {
    fs.mkdirSync(dbDir, { recursive: true });
  } catch (err) {
    console.warn('Could not create data dir:', err.message);
  }
}

// Initialize DB file if it doesn't exist
function initDB() {
  if (!fs.existsSync(DB_PATH)) {
    const initial = {
      users: [],
      loginHistory: []
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
    console.log('✅ Created new database at', DB_PATH);
  }
}

initDB();

// Read DB
function readDB() {
  try {
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading DB:', err.message);
    return { users: [], loginHistory: [] };
  }
}

// Write DB (atomic write to prevent corruption)
function writeDB(data) {
  try {
    const tmpPath = DB_PATH + '.tmp';
    fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2));
    fs.renameSync(tmpPath, DB_PATH);
    return true;
  } catch (err) {
    console.error('Error writing DB:', err.message);
    return false;
  }
}

// ====== User Operations ======

function getAllUsers(callback) {
  const db = readDB();
  // Return in reverse chronological order (newest first)
  const users = [...db.users].sort((a, b) => new Date(b.joined_at) - new Date(a.joined_at));
  callback(null, users);
}

function findUserByGoogleId(googleId, callback) {
  const db = readDB();
  const user = db.users.find(u => u.google_id === googleId);
  callback(null, user || null);
}

function findUserByEmail(email, callback) {
  const db = readDB();
  const user = db.users.find(u => u.email === email);
  callback(null, user || null);
}

function findUserById(id, callback) {
  const db = readDB();
  const user = db.users.find(u => u.id === id);
  callback(null, user || null);
}

function createUser(userData, callback) {
  const db = readDB();
  const newId = db.users.length > 0 ? Math.max(...db.users.map(u => u.id)) + 1 : 1;
  const newUser = {
    id: newId,
    google_id: userData.google_id,
    email: userData.email,
    name: userData.name,
    picture: userData.picture || null,
    joined_at: new Date().toISOString(),
    last_login: new Date().toISOString(),
    login_count: 1,
    is_active: 1
  };
  db.users.push(newUser);
  if (writeDB(db)) {
    callback(null, newUser);
  } else {
    callback(new Error('Failed to write DB'));
  }
}

function updateUserLogin(googleId, name, picture, callback) {
  const db = readDB();
  const idx = db.users.findIndex(u => u.google_id === googleId);
  if (idx === -1) {
    return callback(new Error('User not found'));
  }
  db.users[idx].name = name;
  db.users[idx].picture = picture;
  db.users[idx].last_login = new Date().toISOString();
  db.users[idx].login_count = (db.users[idx].login_count || 0) + 1;
  db.users[idx].is_active = 1;

  if (writeDB(db)) {
    callback(null, db.users[idx]);
  } else {
    callback(new Error('Failed to write DB'));
  }
}

function logLogin(userId, ip, userAgent, callback) {
  const db = readDB();
  db.loginHistory.push({
    id: db.loginHistory.length + 1,
    user_id: userId,
    login_at: new Date().toISOString(),
    ip_address: ip,
    user_agent: userAgent
  });
  // Keep only last 1000 entries to prevent file from growing too large
  if (db.loginHistory.length > 1000) {
    db.loginHistory = db.loginHistory.slice(-1000);
  }
  if (writeDB(db)) {
    callback(null);
  } else {
    callback(new Error('Failed to write DB'));
  }
}

function getStats(callback) {
  const db = readDB();
  const now = new Date();
  const today = now.toISOString().split('T')[0];
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();

  const stats = {
    totalUsers: db.users.length,
    activeUsers: db.users.filter(u => u.is_active).length,
    newUsersToday: db.users.filter(u => u.joined_at.startsWith(today)).length,
    newUsersWeek: db.users.filter(u => u.joined_at >= weekAgo).length,
    totalLogins: db.loginHistory.length,
    loginsToday: db.loginHistory.filter(h => h.login_at.startsWith(today)).length,
    topUsers: [...db.users]
      .sort((a, b) => (b.login_count || 0) - (a.login_count || 0))
      .slice(0, 5)
      .map(u => ({ name: u.name, email: u.email, login_count: u.login_count }))
  };

  callback(null, stats);
}

function getUserLoginHistory(userId, callback) {
  const db = readDB();
  const history = db.loginHistory
    .filter(h => h.user_id === userId)
    .sort((a, b) => new Date(b.login_at) - new Date(a.login_at))
    .slice(0, 50);
  callback(null, history);
}

function setUserActive(userId, isActive, callback) {
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === userId);
  if (idx === -1) return callback(new Error('User not found'));
  db.users[idx].is_active = isActive ? 1 : 0;
  if (writeDB(db)) {
    callback(null, db.users[idx]);
  } else {
    callback(new Error('Failed to write DB'));
  }
}

// Enrich users with total logins
function getAllUsersEnriched(callback) {
  const db = readDB();
  const users = [...db.users]
    .map(u => {
      const totalLogins = db.loginHistory.filter(h => h.user_id === u.id).length;
      const lastLoginRecord = db.loginHistory
        .filter(h => h.user_id === u.id)
        .sort((a, b) => new Date(b.login_at) - new Date(a.login_at))[0];
      return {
        ...u,
        total_logins: totalLogins,
        last_login_recorded: lastLoginRecord?.login_at || null
      };
    })
    .sort((a, b) => new Date(b.joined_at) - new Date(a.joined_at));
  callback(null, users);
}

module.exports = {
  readDB,
  writeDB,
  getAllUsers,
  findUserByGoogleId,
  findUserByEmail,
  findUserById,
  createUser,
  updateUserLogin,
  logLogin,
  getStats,
  getUserLoginHistory,
  setUserActive,
  getAllUsersEnriched,
  DB_PATH
};
