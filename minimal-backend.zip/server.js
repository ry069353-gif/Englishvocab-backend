const express = require('express');
const { OAuth2Client } = require('google-auth-library');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const DB_PATH = process.env.DB_PATH || './data/db.json';

app.use(express.json({ limit: '1mb' }));
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// Simple JSON file DB
function loadDB() {
  try {
    if (!fs.existsSync(path.dirname(DB_PATH))) {
      fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    }
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify({ users: [], logins: [] }, null, 2));
    }
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch (e) {
    return { users: [], logins: [] };
  }
}
function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

const client = new OAuth2Client(GOOGLE_CLIENT_ID);

// Health check
app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// Google login
app.post('/api/auth/google', async (req, res) => {
  try {
    const { credential } = req.body;
    if (!credential) return res.status(400).json({ error: 'Missing credential' });
    if (!GOOGLE_CLIENT_ID) return res.status(500).json({ error: 'Server not configured' });

    const ticket = await client.verifyIdToken({ idToken: credential, audience: GOOGLE_CLIENT_ID });
    const payload = ticket.getPayload();
    if (!payload.email_verified) return res.status(400).json({ error: 'Email not verified' });

    const db = loadDB();
    let user = db.users.find(u => u.google_id === payload.sub);
    const ip = req.headers['x-forwarded-for'] || req.ip || 'unknown';
    const ua = req.headers['user-agent'] || 'unknown';

    if (user) {
      user.name = payload.name;
      user.picture = payload.picture;
      user.last_login = new Date().toISOString();
      user.login_count = (user.login_count || 0) + 1;
    } else {
      user = {
        id: db.users.length + 1,
        google_id: payload.sub,
        email: payload.email,
        name: payload.name || payload.email.split('@')[0],
        picture: payload.picture,
        joined_at: new Date().toISOString(),
        last_login: new Date().toISOString(),
        login_count: 1,
        is_active: 1
      };
      db.users.push(user);
    }
    db.logins.push({ user_id: user.id, at: new Date().toISOString(), ip, ua });
    if (db.logins.length > 500) db.logins = db.logins.slice(-500);
    saveDB(db);

    const token = jwt.sign({ sub: user.id, type: 'user' }, JWT_SECRET, { expiresIn: '30d' });
    res.json({ success: true, token, user: { id: user.id, google_id: user.google_id, email: user.email, name: user.name, picture: user.picture, joined_at: user.joined_at, login_count: user.login_count } });
  } catch (e) {
    console.error('Google auth error:', e);
    res.status(401).json({ error: 'Invalid Google credential' });
  }
});

// Admin login
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    const token = jwt.sign({ sub: username, type: 'admin' }, JWT_SECRET, { expiresIn: '8h' });
    res.json({ success: true, token });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

// Admin middleware
function adminAuth(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const decoded = jwt.verify(auth.slice(7), JWT_SECRET);
    if (decoded.type !== 'admin') return res.status(403).json({ error: 'Admin only' });
    next();
  } catch (e) {
    res.status(401).json({ error: 'Invalid token' });
  }
}

// Admin: get all users
app.get('/api/admin/users', adminAuth, (req, res) => {
  const db = loadDB();
  const users = db.users.map(u => ({
    ...u,
    total_logins: db.logins.filter(l => l.user_id === u.id).length
  })).sort((a, b) => new Date(b.joined_at) - new Date(a.joined_at));
  res.json({ success: true, count: users.length, users });
});

// Admin: stats
app.get('/api/admin/stats', adminAuth, (req, res) => {
  const db = loadDB();
  const today = new Date().toISOString().split('T')[0];
  const weekAgo = new Date(Date.now() - 7*24*60*60*1000).toISOString();
  res.json({
    success: true,
    stats: {
      totalUsers: db.users.length,
      activeUsers: db.users.filter(u => u.is_active).length,
      newUsersToday: db.users.filter(u => u.joined_at.startsWith(today)).length,
      newUsersWeek: db.users.filter(u => u.joined_at >= weekAgo).length,
      totalLogins: db.logins.length,
      loginsToday: db.logins.filter(l => l.at.startsWith(today)).length
    }
  });
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
